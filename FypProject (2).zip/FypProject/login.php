<?php
session_start();

// Check if user is logged in
$isGuest = !isset($_SESSION['username']);
$username = $isGuest ? "Guest" : $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Crispicay</title>
    <script src="https://kit.fontawesome.com/a53342ebb1.js" crossorigin="anonymous"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #000;
            color: #fff;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #000;
            padding: 0;
            text-align: center;
            position: relative;
        }

        .logo img {
            display: none;
        }

        .header-image {
            width: 100%;
            overflow: hidden;
            position: relative;
        }

        .header-image h1 {
            font-family: 'Segoe Script', cursive;
            font-size: 55px;
            color: #fff;
            margin-bottom: 2px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 1;
        }

        .header-image img {
            width: 100%;
            height: auto;
            max-height: 300px;
            position: relative;
            z-index: 0;
        }

        .navbar {
            background-color: #000;
            padding: 10px;
            text-align: center;
        }

        .navbar ul {
            list-style-type: none;
            padding: 0;
        }

        .navbar ul li {
            display: inline;
            margin: 0 10px;
        }

        .navbar ul li a {
            text-decoration: none;
            color: #fff;
        }

        .navbar ul li a:hover {
            color: #ff0000;
        }

        .welcome {
            position: absolute;
            top: 10px;
            right: 10px;
            color: #fff;
        }

        main {
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #ff0000;
        }

        .login-container {
            max-width: 400px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .login-form {
            text-align: left;
        }

        .login-form h2 {
            margin-bottom: 20px;
            color: #333;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #ff0000;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #cc0000;
        }

        .bottom-section {
            background-color: #222;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-image">
            <a href="home.php"><h1><b>Crispicay</b></h1></a>
            <img src="Menu Images/Flames header.jpg" alt="Header Image">
        </div>
        <nav class="navbar">
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="order.php">Order Now</a></li>
                <li><a href="contact.php">Contact</a></li>
                <?php if ($isGuest): ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Register</a></li>
                <?php else: ?>
                    <li><a href="logout.php">Logout</a></li>
                <?php endif; ?>
            </ul>
        </nav>
        <div class="welcome">
            <p>Welcome, <?php echo $username; ?></p>
        </div>
    </header>

    <br>
    <div class="login-container"> 
        <form class="login-form" action="doLogin.php" method="post">
            <h2><b>Login</b></h2>
            <div class="form-group">
                <label for="username" style="color: black;"><i class="fa-solid fa-user"></i> Username:</label>
                <input type="text" id="username" name="username" placeholder="Enter your username" required>
            </div>
            <div class="form-group">
                <label for="password" style="color: black;"><i class="fa-solid fa-lock"></i> Password:</label>
                <input type="password" id="password" name="password" placeholder="Enter your password" required>
            </div>
            <button type="submit">Login</button>
        </form>
    </div>

    <p style="text-align: center">Not a user yet? <a href="register.php">Join now</a>!</p>

    <div class="bottom-section">
        <br>
        <div class="social-icons" style="font-size: 25px">
            <i class="fa-brands fa-square-instagram"></i>
            <i class="fa-brands fa-square-x-twitter"></i>
            <i class="fa-brands fa-facebook"></i>
        </div>
        <hr style="color: white">
        <p>&copy; <?php echo date("Y"); ?> Crispicay</p>
    </div>
</body>
</html>
