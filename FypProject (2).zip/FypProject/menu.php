<?php
session_start();

// Database connection
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "fyp_database";
$link = mysqli_connect($db_host, $db_user, $db_pass, $db_name) or die(mysqli_connect_error());

// Fetching menu items from the database
$query = "SELECT * FROM product";
$result = mysqli_query($link, $query);
$menu_items = [];

if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $menu_items[] = $row;
    }
} else {
    echo "Error: " . mysqli_error($link);
}

// Check if user is logged in
$is_logged_in = isset($_SESSION['userId']);
$username = $is_logged_in ? $_SESSION['username'] : "Guest";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu - Chicken Food Website</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #000;
            color: #fff;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #000;
            padding: 0;
            text-align: center;
            position: relative;
        }

        .logo img {
            display: none; /* Hide the logo image */
        }

        .header-image {
            width: 100%;
            overflow: hidden;
            position: relative;
        }

        .header-image h1 {
            font-family: 'Segoe Script', cursive;
            font-size: 55px;
            color: #fff;
            margin-bottom: 2px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 1;
        }

        .header-image img {
            width: 100%;
            height: auto;
            max-height: 300px;
            position: relative;
            z-index: 0;
        }

        .navbar {
            background-color: #000;
            padding: 10px;
            text-align: center;
        }

        .navbar ul {
            list-style-type: none;
            padding: 0;
        }

        .navbar ul li {
            display: inline;
            margin: 0 10px;
        }

        .navbar ul li a {
            text-decoration: none;
            color: #fff;
        }

        .navbar ul li a:hover {
            color: #ff0000;
        }

        .welcome {
            position: absolute;
            top: 10px;
            right: 10px;
            color: #fff;
        }

        main {
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #ff0000;
        }

        .menu-items {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .menu-item {
            width: 200px;
            margin: 20px;
            text-align: center;
            background-color: #333;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }

        .menu-item img {
            width: 100%;
            height: auto;
            border-radius: 5px;
        }

        .menu-item h2 {
            color: #ff0000;
        }

        .menu-item p {
            color: #fff;
            margin-top: 10px;
        }

        .menu-item span {
            color: #ff0000;
            font-weight: bold;
        }

        .spacer {
            height: 50px;
        }

        footer {
            background-color: #000;
            color: #fff;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo"></div>
        <div class="header-image">
            <h1>Crispicay</h1>
            <img src="Menu Images/Flames header.jpg" alt="Header Image">
        </div>
        <nav class="navbar">
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="order.php">Order Now</a></li> 
                <li><a href="contact.php">Contact</a></li>
                <?php if ($is_logged_in): ?>
                    <li><a href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Register</a></li>
                <?php endif; ?>
            </ul>
        </nav>
        <div class="welcome">
            <p>Welcome, <?php echo htmlspecialchars($username); ?></p>
        </div>
    </header>
    <main>
        <h1>Our Menu</h1>
        
        <div class="menu-items">
            <?php foreach ($menu_items as $item): ?>
                <div class="menu-item">
                    <img src="Menu Images/<?php echo htmlspecialchars($item['picture']); ?>" alt="<?php echo htmlspecialchars($item['product_name']); ?>">
                    <h2><?php echo htmlspecialchars($item['product_name']); ?></h2>
                    <p>Price: <span>$<?php echo htmlspecialchars($item['price']); ?></span></p>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="spacer"></div>
    </main>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> Chicken Food Website</p>
    </footer>
</body>
</html>
