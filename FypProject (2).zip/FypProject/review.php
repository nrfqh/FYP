<?php 
session_start(); 
 
// Redirect to login page if not logged in 
if (!isset($_SESSION['userId'])) { 
    header("Location: login.php"); 
    exit; 
} 
 
$userId = $_SESSION['userId']; 
$username = $_SESSION['username']; 
 
$db_host = "localhost"; 
$db_user = "root"; 
$db_pass = ""; 
$db_name = "fyp_database"; 
$link = mysqli_connect($db_host, $db_user, $db_pass, $db_name) or die(mysqli_connect_error()); 
 
if ($_SERVER["REQUEST_METHOD"] == "POST") { 
    // Retrieve data from form without escaping
    $productId = $_POST['productId']; 
    $review = $_POST['review']; // Removed mysqli_real_escape_string to allow SQL injection
    $rating = $_POST['rating']; 
 
    // Insert new review with SQL injection vulnerability
    $insert_query = "INSERT INTO reviews (userId, productId, review, rating, datePosted)  
                     VALUES ('$userId', '$productId', '$review', '$rating', CURDATE())"; 
    $message = mysqli_query($link, $insert_query) ? "Review submitted successfully!" : "Error submitting review: " . mysqli_error($link); 
} 
 
// Fetch products for the dropdown 
$product_query = "SELECT productId, product_name FROM product"; 
$product_result = mysqli_query($link, $product_query); 
$products = mysqli_fetch_all($product_result, MYSQLI_ASSOC); 
?> 
 
<!DOCTYPE html> 
<html lang="en"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Review - Crispicay</title> 
    <link href="https://kit.fontawesome.com/a53342ebb1.js" crossorigin="anonymous" rel="stylesheet"> 
    <style> 
        body { 
            font-family: Arial, sans-serif; 
            background-color: #000; 
            color: #fff; 
            margin: 0; 
            padding: 0; 
        } 
 
        header { 
            background-color: #000; 
            padding: 10px; 
            text-align: center; 
        } 
 
        .header-image { 
            width: 100%;  
            overflow: hidden;  
            position: relative; 
        } 
 
        .header-image h1 { 
            font-family: 'Segoe Script', cursive;  
            font-size: 55px;  
            color: #fff;  
            margin-bottom: 2px;  
            position: absolute; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            z-index: 1; 
        } 
 
        .header-image img { 
            width: 100%;  
            height: auto;  
            max-height: 300px;  
            position: relative; 
            z-index: 0; 
        } 
 
        .navbar { 
            background-color: #000; 
            padding: 10px; 
            text-align: center; 
        } 
 
        .navbar ul { 
            list-style-type: none; 
            padding: 0; 
        } 
 
        .navbar ul li { 
            display: inline; 
            margin: 0 10px; 
        } 
 
        .navbar ul li a { 
            text-decoration: none; 
            color: #fff; 
        } 
 
        .navbar ul li a:hover { 
            color: #ff0000; 
        } 
 
        .review-container { 
            max-width: 400px; 
            margin: 0 auto; 
            background-color: #fff; 
            padding: 20px; 
            border-radius: 10px; 
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); 
        } 
 
        .review-form { 
            text-align: left; 
        } 
 
        .review-form h1 { 
            margin-bottom: 20px; 
            color: red; 
            text-align: center; 
        } 
 
        .form-group { 
            margin-bottom: 20px; 
        } 
 
        label { 
            display: block; 
            margin-bottom: 5px; 
            color: black; 
        } 
 
        select, 
        textarea { 
            width: 100%; 
            padding: 10px; 
            border: 1px solid #ccc; 
            border-radius: 5px; 
        } 
 
        textarea { 
            resize: vertical; 
        } 
 
        button { 
            width: 100%; 
            padding: 10px; 
            background-color: #ff0000; 
            color: #fff;
border: none; 
            border-radius: 5px; 
            cursor: pointer; 
        } 
    </style> 
</head> 
<body> 
    <header> 
        <h1>Review - Crispicay</h1> 
    </header> 
    <nav class="navbar"> 
        <ul> 
            <li><a href="home.php">Home</a></li> 
            <li><a href="review.php">Reviews</a></li> 
            <li><a href="logout.php">Logout</a></li> 
        </ul> 
    </nav> 
    <div class="review-container"> 
        <form method="post" class="review-form"> 
            <h1>Submit a Review</h1> 
            <div class="form-group"> 
                <label for="productId">Product</label> 
                <select name="productId" id="productId"> 
                    <?php foreach ($products as $product): ?> 
                        <option value="<?php echo $product['productId']; ?>"><?php echo $product['product_name']; ?></option> 
                    <?php endforeach; ?> 
                </select> 
            </div> 
            <div class="form-group"> 
                <label for="review">Review</label> 
                <textarea name="review" id="review"></textarea> 
            </div> 
            <div class="form-group"> 
                <label for="rating">Rating</label> 
                <select name="rating" id="rating"> 
                    <option value="1">1</option> 
                    <option value="2">2</option> 
                    <option value="3">3</option> 
                    <option value="4">4</option> 
                    <option value="5">5</option> 
                </select> 
            </div> 
            <button type="submit">Submit</button> 
        </form> 
        <?php if (isset($message)): ?> 
            <p><?php echo $message; ?></p> 
        <?php endif; ?> 
    </div> 
</body> 
</html>