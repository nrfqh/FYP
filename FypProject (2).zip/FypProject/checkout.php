<?php
session_start();
include 'dbFunctions.php'; // Include the database connection file

// Check if user is logged in
$is_logged_in = isset($_SESSION['userId']);
$username = $is_logged_in ? $_SESSION['username'] : "Guest";
$discount = $is_logged_in ? 0.95 : 1.00; // 5% discount for logged-in users
$delivery_fee = $is_logged_in ? 8 : 10; // $8 delivery fee for logged-in users, $10 for guest users

// Retrieve form data
$name = mysqli_real_escape_string($link, $_POST['name']);
$phone = mysqli_real_escape_string($link, $_POST['phone']);
$address = mysqli_real_escape_string($link, $_POST['address']);
$order_details = [];
$total_price = 0;

// Process each item and calculate the total price
if ($_POST['family_combo_qty'] > 0) {
    $qty = intval($_POST['family_combo_qty']);
    $price = 12.99 * $qty;
    $total_price += $price;
    $order_details[] = "Family Combo x $qty";
}

if ($_POST['hot_spicy_qty'] > 0) {
    $qty = intval($_POST['hot_spicy_qty']);
    $price = 10.99 * $qty;
    $total_price += $price;
    $order_details[] = "Hot & Spicy Chicken x $qty";
}

if ($_POST['soft_garlic_qty'] > 0) {
    $qty = intval($_POST['soft_garlic_qty']);
    $price = 11.99 * $qty;
    $total_price += $price;
    $order_details[] = "Soft Garlic Chicken x $qty";
}

if ($_POST['orange_fanta_qty'] > 0) {
    $qty = intval($_POST['orange_fanta_qty']);
    $price = 2.50 * $qty;
    $total_price += $price;
    $order_details[] = "Orange Fanta x $qty";
}

if ($_POST['grape_fanta_qty'] > 0) {
    $qty = intval($_POST['grape_fanta_qty']);
    $price = 2.50 * $qty;
    $total_price += $price;
    $order_details[] = "Grape Fanta x $qty";
}

// Apply discount and add delivery fee
$total_price = ($total_price * $discount) + $delivery_fee;

// Round total price to two decimal places
$total_price = round($total_price, 2);

// Insert order into the database
$order_details_str = mysqli_real_escape_string($link, implode(", ", $order_details));
$user_id = $is_logged_in ? $_SESSION['userId'] : 'NULL'; // Set userId to NULL if not logged in
$query = "INSERT INTO orders (food_ordered, customer_name, delivery_address, total_price, userId) 
          VALUES ('$order_details_str', '$name', '$address', '$total_price', $user_id)";

if (mysqli_query($link, $query)) {
    $order_id = mysqli_insert_id($link);
} else {
    die("Error: " . mysqli_error($link));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation - Crispicay</title>
    <style>
        /* Add your custom styles here */
        body {
            font-family: Arial, sans-serif;
            background-color: #000;
            color: #fff;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #000;
            padding: 0;
            text-align: center;
            position: relative; /* Ensure proper positioning of the header image */
        }

        .logo img {
            display: none; /* Hide the logo image */
        }

        .header-image {
            width: 100%; /* Make the image cover the entire width of the page */
            overflow: hidden; /* Hide overflowing content */
            position: relative;
        }

        .header-image h1 {
            font-family: 'Segoe Script', cursive; /* Use a cursive font */
            font-size: 55px; /* Adjust the font size */
            color: #fff; /* Font color */
            margin-bottom: 2px; /* Add some space below the header */
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 1;
        }

        .header-image img {
            width: 100%; /* Make the image cover the entire width of its container */
            height: auto; /* Maintain aspect ratio */
            max-height: 300px; /* Limit the maximum height of the image */
            position: relative;
            z-index: 0;
        }

        .navbar {
            background-color: #000;
            padding: 10px;
            text-align: center;
        }

        .navbar ul {
            list-style-type: none;
            padding: 0;
        }

        .navbar ul li {
            display: inline;
            margin: 0 10px;
        }

        .navbar ul li a {
            text-decoration: none;
            color: #fff;
        }

        .navbar ul li a:hover {
            color: #ff0000;
        }

        main {
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #ff0000;
        }

        .order-summary {
            background-color: #333;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            text-align: center;
        }

        .order-summary p {
            color: #fff;
            margin: 10px 0;
        }

        .order-summary .total {
            font-size: 1.5em;
            color: #ff0000;
        }

        .order-summary .delivery {
            font-size: 1.2em;
            color: #ff0000;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <!-- Remove the "Chicken Food Website Logo" text -->
        </div>
        <div class="header-image">
            <!-- Add the "Crispicay" header -->
            <h1>Crispicay</h1>
            <img src="Menu Images/Flames header.jpg" alt="Header Image">
        </div>
        <nav class="navbar navbar-expand-lg navbar-light"> <!-- Add navbar classes -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="menu.php">Menu</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="order.php">Order Now</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <?php if ($is_logged_in): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Logout</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="register.php">Register</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </nav>
    </header>
    <main>
        <h1>Order Confirmation</h1>
        <div class="order-summary">
            <p>Thank you for your order!</p>
            <p>Your Order No. is <strong><?php echo htmlspecialchars($order_id); ?></strong></p>
            <p>Order Details: <?php echo htmlspecialchars($order_details_str); ?></p>
            <p class="total">Total Price: $<?php echo number_format($total_price, 2); ?></p>
            <p class="delivery">Delivery Fee: $<?php echo number_format($delivery_fee, 2); ?></p>
        </div>
    </main>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> Crispicay</p>
    </footer>
</body>
</html>
