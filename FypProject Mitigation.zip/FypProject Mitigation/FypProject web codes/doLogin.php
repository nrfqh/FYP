<?php
session_start();
include "dbFunctions.php";

if (isset($_SESSION['userId'])) {
    $msg = "You are already logged in. <a href='logout.php'>Logout?</a></p>";
} else {
    if (isset($_POST['username']) && isset($_POST['password'])) {
        // Sanitize user inputs to prevent SQL Injection
        $entered_username = mysqli_real_escape_string($link, $_POST['username']);
        $entered_password = mysqli_real_escape_string($link, $_POST['password']);

        // Use parameterized query to prevent SQL Injection
        $queryCheck = "SELECT * FROM users WHERE username=? AND password=?";
        $stmt = mysqli_prepare($link, $queryCheck);
        mysqli_stmt_bind_param($stmt, 'ss', $entered_username, $entered_password);
        mysqli_stmt_execute($stmt);
        $resultCheck = mysqli_stmt_get_result($stmt);

        $msg = "";

        if (mysqli_num_rows($resultCheck) == 1) {
            $row = mysqli_fetch_array($resultCheck);
            $_SESSION['userId'] = $row['userId'];
            $_SESSION['username'] = $row['username'];

            $msg = "<p><i>You are logged in as " . htmlspecialchars($_SESSION['username'], ENT_QUOTES, 'UTF-8') . "</p>"; // Prevent XSS
            $msg .= "<p><a href='home.php'>Home</a></p> <a href='logout.php'>Logout</a></p>";
        } else {
            $msg = "<p>Sorry, you must enter a valid username and password to log in</p>";
            $msg .= "<p><a href='login.php'>Go back to login page</a></p>";
        }
        mysqli_stmt_close($stmt);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Crispicay</title>
    <script src="https://kit.fontawesome.com/a53342ebb1.js" crossorigin="anonymous"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #000;
            color: #fff;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #000;
            padding: 0;
            text-align: center;
            position: relative;
        }

        .logo img {
            display: none;
        }

        .header-image {
            width: 100%;
            overflow: hidden;
            position: relative;
        }

        .header-image h1 {
            font-family: 'Segoe Script', cursive;
            font-size: 55px;
            color: #fff;
            margin-bottom: 2px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 1;
        }

        .header-image img {
            width: 100%;
            height: auto;
            max-height: 300px;
            position: relative;
            z-index: 0;
        }

        .navbar {
            background-color: #000;
            padding: 10px;
            text-align: center;
        }

        .navbar ul {
            list-style-type: none;
            padding: 0;
        }

        .navbar ul li {
            display: inline;
            margin: 0 10px;
        }

        .navbar ul li a {
            text-decoration: none;
            color: #fff;
        }

        .navbar ul li a:hover {
            color: #ff0000;
        }

        main {
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #ff0000;
        }

        .bottom-section {
            background-color: #222;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-image">
            <a href="home.php"><h1><b>Crispicay</b></h1></a>
            <img src="Menu Images/flames header.jpg" alt="Header Image">
        </div>
        <nav class="navbar">
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="order.php">Order Now</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">Register</a></li>
            </ul>
        </nav>
    </header>
    <br>
    <main>
        <p><?php echo $msg; ?></p>
    </main>
    <div class="bottom-section">
        <br>
        <p>&copy; <?php echo date("Y"); ?> Crispicay</p>
    </div>
</body>
</html>
