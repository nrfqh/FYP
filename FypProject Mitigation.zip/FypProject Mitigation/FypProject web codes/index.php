<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chicken Food Website</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Welcome to our Chicken Food Website</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="login.php">Login</a></li> 
                <li><a href="register.php">Register</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h2>Delicious Chicken Dishes</h2>
        <p>Explore our mouth-watering chicken dishes.</p>
        <!-- You can add more content here -->
    </main>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> Chicken Food Website</p>
    </footer>
</body>
</html>