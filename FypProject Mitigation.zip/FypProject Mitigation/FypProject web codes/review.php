<?php
session_start();

// Redirect to login page if not logged in
if (!isset($_SESSION['userId'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['userId'];
$username = $_SESSION['username'];

$db_host = 'localhost';
$db_user = 'root';
$db_password = '';
$db_name = 'fyp_database';

$link = mysqli_connect($db_host, $db_user, $db_password, $db_name);

if (mysqli_connect_errno()) {
    die("Failed to connect to MySQL: " . mysqli_connect_error());
}

$queryProduct = "SELECT productId, product_name FROM product";
$resultProduct = mysqli_query($link, $queryProduct);
$products = mysqli_fetch_all($resultProduct, MYSQLI_ASSOC);

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productId = $_POST['productId'];
    $review = htmlspecialchars($_POST['review']);
    $rating = $_POST['rating'];
    $datePosted = date("Y-m-d H:i:s");

    $stmt = $link->prepare("INSERT INTO reviews (review, rating, userId, productId, datePosted) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("siiis", $review, $rating, $userId, $productId, $datePosted);

    if ($stmt->execute()) {
        $message = "Review added successfully!";
    } else {
        $message = "Error adding review: " . $stmt->error;
    }

    $stmt->close();
}

mysqli_close($link);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Submit a Review</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #000;
            color: #fff;
        }

        .container {
            width: 50%;
            margin: auto;
            padding: 20px;
            background-color: #333;
            border-radius: 10px;
        }

        h1 {
            text-align: center;
            color: #ff0000;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin: 10px 0 5px;
        }

        input[type="text"], select, textarea {
            padding: 10px;
            border-radius: 5px;
            border: none;
        }

        input[type="submit"] {
            background-color: #ff0000;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }

        input[type="submit"]:hover {
            background-color: #ff5555;
        }

        .message {
            text-align: center;
            margin-top: 20px;
        }

        a {
            color: #ff0000;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Submit a Review</h1>
        <form method="POST" action="review.php">
            <label for="productId">Product</label>
            <select name="productId" id="productId" required>
                <?php foreach ($products as $product) { ?>
                    <option value="<?php echo $product['productId']; ?>"><?php echo htmlspecialchars($product['product_name']); ?></option>
                <?php } ?>
            </select>

            <label for="review">Review</label>
            <textarea name="review" id="review" rows="4" required></textarea>

            <label for="rating">Rating</label>
            <input type="number" name="rating" id="rating" min="1" max="5" required>

            <input type="submit" value="Submit Review">
        </form>
        <?php if ($message) { ?>
            <p class="message"><?php echo htmlspecialchars($message); ?></p>
        <?php } ?>
        <p><a href="home.php">Back to Home</a></p>
    </div>
</body>
</html>
