<?php
session_start();

if (isset($_SESSION['userId'])) {
    session_destroy();
    $_SESSION = array();
}
$msg = "You have logged out. <br/> <a href='login.php'>Login?</a>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Logout - Crispicay</title>
    <script src="https://kit.fontawesome.com/a53342ebb1.js" crossorigin="anonymous"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #000;
            color: #fff;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #000;
            padding: 0;
            text-align: center;
            position: relative;
        }

        .logo img {
            display: none;
        }

        .header-image {
            width: 100%;
            overflow: hidden;
            position: relative;
        }

        .header-image h1 {
            font-family: 'Segoe Script', cursive;
            font-size: 55px;
            color: #fff;
            margin-bottom: 2px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 1;
        }

        .header-image img {
            width: 100%;
            height: auto;
            max-height: 300px;
            position: relative;
            z-index: 0;
        }

        .navbar {
            background-color: #000;
            padding: 10px;
            text-align: center;
        }

        .navbar ul {
            list-style-type: none;
            padding: 0;
        }

        .navbar ul li {
            display: inline;
            margin: 0 10px;
        }

        .navbar ul li a {
            text-decoration: none;
            color: #fff;
        }

        .navbar ul li a:hover {
            color: #ff0000;
        }

        main {
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #ff0000;
        }

        .bottom-section {
            background-color: #222;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        .social-icons {
            font-size: 25px;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-image">
            <a href="home.php"><h1><b>Crispicay</b></h1></a>
            <img src="Menu Images/flames header.jpg" alt="Header Image">
        </div>
        <nav class="navbar">
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="order.php">Order Now</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">Register</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <p><?php echo $msg; ?></p>
    </main>

    <div class="bottom-section">
        <div class="social-icons">
            <i class="fa-brands fa-square-instagram"></i>
            <i class="fa-brands fa-square-x-twitter"></i>
            <i class="fa-brands fa-facebook"></i>
        </div>
        <hr style="color: white">
        <p>&copy; <?php echo date("Y"); ?> Crispicay</p>
    </div>
</body>
</html>